# 🏥 نظام إدارة العيادة الطبية
## Clinic Management System

![Laravel](https://img.shields.io/badge/Laravel-11-FF2D20?style=flat-square&logo=laravel)
![PHP](https://img.shields.io/badge/PHP-8.2+-777BB4?style=flat-square&logo=php)
![Filament](https://img.shields.io/badge/Filament-3.2-F03D3D?style=flat-square)
![License](https://img.shields.io/badge/License-MIT-green?style=flat-square)

---

## 📋 نبذة عن المشروع

نظام متكامل لإدارة العيادات الطبية يوفر حلاً شاملاً للمتطلبات الإدارية والتشغيلية للعيادات الحديثة. يتم بناؤه باستخدام إطار عمل Laravel الحديث مع واجهة إدارية متقدمة قائمة على Filament.

### ✨ الميزات الرئيسية

- 🔐 **نظام المستخدمين والصلاحيات**: إدارة متقدمة للأدوار والأذونات
- 📅 **إدارة المواعيد**: نظام احجز مرن للمواعيد الطبية
- 👨‍⚕️ **إدارة الأطباء**: معلومات شاملة عن الأطباء والتخصصات
- 👥 **إدارة المرضى**: ملفات المرضى والسجلات الطبية
- 💊 **إدارة الأدوية**: تتبع الأدوية والمخزون
- 📊 **التقارير والإحصائيات**: تحليل بيانات شامل
- 🌍 **دعم اللغات**: دعم العربية والإنجليزية
- 🗄️ **النسخ الاحتياطي**: نظام النسخ الاحتياطي التلقائي
- 📝 **سجل النشاط**: تتبع جميع العمليات والتغييرات
- 📷 **مكتبة الوسائط**: إدارة الصور والملفات

---

## 🛠️ المتطلبات

- **PHP**: 8.2 أو أحدث
- **Composer**: أداة إدارة المكتبات في PHP
- **MySQL/MariaDB**: قاعدة البيانات
- **Node.js**: لتجميع الأصول (Assets)
- **Git**: نظام التحكم بالإصدارات

---

## 📦 المكتبات والأدوات المستخدمة

### Backend
```json
{
  "laravel/framework": "^11.31",
  "filament/filament": "^3.2",
  "spatie/laravel-activitylog": "^4.8",
  "spatie/laravel-backup": "^8.0",
  "spatie/laravel-medialibrary": "^11.0",
  "spatie/laravel-translatable": "^6.0"
}
```

### Frontend
- **Tailwind CSS**: إطار عمل CSS
- **Vite**: أداة البناء الحديثة
- **Alpine.js**: إطار عمل JavaScript خفيف الوزن

### Development Tools
- **Laravel Pint**: أداة تنسيق الأكواد
- **PHPUnit**: اختبار الأكواد
- **Laravel Sail**: بيئة التطوير

---

## ⚙️ التثبيت والإعداد

### 1. استنساخ المستودع

```bash
git clone https://github.com/japanan758-bit/D.git
cd D
```

### 2. تثبيت المكتبات

```bash
# تثبيت مكتبات PHP
composer install

# تثبيت مكتبات Node.js
npm install
```

### 3. إعداد متغيرات البيئة

```bash
# نسخ ملف البيئة
cp .env.example .env

# إنشاء مفتاح التطبيق
php artisan key:generate
```

### 4. إنشاء قاعدة البيانات

```bash
# تشغيل الترحيلات
php artisan migrate

# ملء البيانات الأولية (اختياري)
php artisan db:seed
```

### 5. تجميع الأصول

```bash
# في بيئة التطوير
npm run dev

# في بيئة الإنتاج
npm run build
```

### 6. بدء خادم التطوير

```bash
php artisan serve
```

ستكون التطبيق متاحة على: `http://localhost:8000`

---

## 🚀 النشر على الإنتاج (Hostinger)

### المتطلبات الأساسية
- ✅ شهادة SSL
- ✅ دعم PHP 8.2+
- ✅ تفعيل extensions: `curl`, `json`, `mbstring`, `xml`, `zip`
- ✅ السماح بالـ mod_rewrite

### خطوات النشر

1. **رفع الملفات**
   ```bash
   # استخدم FTP أو Git
   git push origin main
   ```

2. **تشغيل الترحيلات**
   ```bash
   php artisan migrate --force
   ```

3. **تحسين الأداء**
   ```bash
   php artisan config:cache
   php artisan route:cache
   php artisan view:cache
   ```

4. **إعداد الأذونات**
   ```bash
   chmod -R 775 storage bootstrap/cache
   chmod -R 755 public
   ```

📖 اطلع على ملف [hostinger_deployment_guide.md](hostinger_deployment_guide.md) للمزيد من التفاصيل.

---

## 🔧 الهيكل المشروع

```
D/
├── app/                          # كود التطبيق
│   ├── Http/
│   │   ├── Controllers/          # متحكمات التطبيق
│   │   ├── Middleware/           # البرمجيات الوسيطة
│   │   └── Requests/             # طلبات التحقق
│   ├── Models/                   # نماذج قاعدة البيانات
│   ├── Services/                 # طبقة الخدمات
│   └── Filament/                 # الواجهة الإدارية
├── database/
│   ├── migrations/               # ملفات الترحيل
│   ├── seeders/                  # بيانات البذر
│   └── database_complete_structure.sql
├── public/
│   ├── build/                    # الأصول المُرجَّلة
│   └── images/                   # الصور والأيقونات
├── resources/
│   ├── views/                    # قوالب العرض
│   └── lang/                     # ملفات اللغات
├── routes/
│   ├── web.php                   # مسارات الويب
│   └── api.php                   # مسارات API
├── storage/                      # تخزين الملفات
├── config/                       # ملفات الإعدادات
├── .env                          # متغيرات البيئة
├── composer.json                 # مكتبات PHP
├── package.json                  # مكتبات JavaScript
└── vite.config.js                # إعدادات Vite
```

---

## 🌐 الوثائق الإضافية

- 📘 [دليل النشر على Hostinger](hostinger_deployment_guide.md)
- 🏥 [تقرير الجهوزية](README_DEPLOYMENT.md)
- ✅ [فحص الصحة قبل النشر](pre_deployment_health_check.php)
- 🗄️ [هيكل قاعدة البيانات الكامل](database_complete_structure.sql)

---

## 🔒 الأمان

- ✅ التحقق من البيانات والتطهير
- ✅ الحماية من CSRF و XSS
- ✅ تشفير كلمات المرور
- ✅ معدل التحديث والتصحيحات الأمنية
- ✅ استخدام HTTPS في الإنتاج

---

## 🧪 الاختبار

```bash
# تشغيل الاختبارات
php artisan test

# تشغيل الاختبارات مع التقرير
php artisan test --coverage
```

---

## 📧 الدعم والتواصل

للمساهمة أو الإبلاغ عن مشاكل:
- 📝 أنشئ Issue
- 🔄 أرسل Pull Request
- 💬 تواصل عبر البريد الإلكتروني

---

## 📄 الترخيص

هذا المشروع مرخص تحت رخصة MIT. اطلع على ملف [LICENSE](LICENSE) للمزيد.

---

## 👨‍💻 المساهمون

شكراً لجميع المساهمين الذين ساعدوا في تطوير هذا المشروع!

---

## 📊 إحصائيات المشروع

| المقياس | القيمة |
|---------|--------|
| **لغة البرمجة الرئيسية** | PHP 8.2+ |
| **إطار العمل** | Laravel 11 |
| **الواجهة الإدارية** | Filament 3.2 |
| **قاعدة البيانات** | MySQL |
| **حجم المشروع** | ~14,500+ ملف |
| **حجم Vendor** | ~75 MB |
| **عدد المكتبات** | +50 مكتبة |

---

## 🚀 الخطوات التالية

- [ ] تطوير ميزات إضافية
- [ ] إضافة API متقدمة
- [ ] تحسين الأداء
- [ ] إضافة اختبارات شاملة
- [ ] توسيع الوثائق

---

**آخر تحديث**: نوفمبر 2025

