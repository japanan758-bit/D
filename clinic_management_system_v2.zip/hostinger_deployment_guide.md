# دليل النشر المفصل خطوة بخطوة - Hostinger

## 📋 نظرة عامة
هذا الدليل يحتوي على خطوات مفصلة لنشر نظام إدارة العيادة على استضافة Hostinger. تم حل جميع المشاكل المكتشفة سابقاً.

---

## 🎯 الحالة الحالية للمشروع

### ✅ المشاكل التي تم حلها:
1. **ملف قاعدة البيانات SQL**: تم إنشاء `database_complete_structure.sql` (806 سطر)
2. **ملف .env للإنتاج**: تم إنشاء `production.env` محسن لـ Hostinger
3. **Migration Conflict**: تم حذف الملف المتضارب
4. **Assets Files**: تم نسخ جميع الملفات المطلوبة إلى public_html
5. **File Structure**: تم تنظيم جميع المكونات بشكل صحيح

### 📊 حالة النظام:
- **المكونات الأساسية**: ✅ 100% جاهزة
- **التكاملات**: ✅ 18 تكامل جاهز للتفعيل
- **Database**: ✅ Schema كامل (23 جدول)
- **Admin Panel**: ✅ Filament مع Widgets
- **Frontend**: ✅ UI/UX مكتمل
- **Chatbot**: ✅ متقدم مع 4+ APIs

---

## 🔧 المتطلبات المسبقة

### 1. معلومات الاستضافة من Hostinger:
- [ ] **Database Name**: اسم قاعدة البيانات
- [ ] **Database Username**: اسم المستخدم
- [ ] **Database Password**: كلمة المرور
- [ ] **Domain URL**: رابط الموقع
- [ ] **Email SMTP**: بيانات البريد الإلكتروني

### 2. API Keys (اختيارية للبداية):
- [ ] **OpenRouter API Key** (مجاني - للمبتدئين)
- [ ] **Google Maps API Key** (مجاني محدود)

---

## 🚀 الخطوة 1: إعداد قاعدة البيانات

### 1.1 إنشاء قاعدة البيانات في Hostinger
1. الدخول إلى **cPanel**
2. البحث عن **"MySQL Databases"**
3. إنشاء قاعدة بيانات جديدة:
   - اسم قاعدة البيانات: `your_domain_clinic`
4. إنشاء مستخدم قاعدة بيانات:
   - اسم المستخدم: `your_domain_user`
   - كلمة مرور قوية
5. ربط المستخدم بقاعدة البيانات مع **All Privileges**

### 1.2 استيراد البيانات
1. الدخول إلى **phpMyAdmin** في cPanel
2. اختيار قاعدة البيانات الجديدة
3. الضغط على **"Import"**
4. رفع الملف: `database_complete_structure.sql`
5. الضغط **"Go"** للتنفيذ

### 1.3 التحقق من الاستيراد
```sql
-- تشغيل هذا الاستعلام في phpMyAdmin للتأكد
SHOW TABLES;

-- يجب أن يظهر:
-- api_integrations, appointments, users, services, etc.
```

---

## 📤 الخطوة 2: رفع الملفات

### 2.1 استخدام File Manager
1. الدخول إلى **File Manager** في cPanel
2. الانتقال إلى مجلد `public_html`
3. حذف جميع الملفات الموجودة (إذا كانت فارغة)

### 2.2 رفع الملفات
رفع **محتويات** مجلد `final-project` إلى `public_html`:

#### 📁 الملفات الأساسية المطلوب رفعها:
```
public_html/
├── index.php (ملف Laravel الرئيسي)
├── .htaccess (ملف Apache)
├── user.ini (ملف PHP)
├── assets/ (ملفات CSS/JS)
├── icons/ (الأيقونات)
├── app/ (كود PHP)
├── bootstrap/ (Bootstrap Laravel)
├── config/ (ملفات الإعداد)
├── database/ (Database files)
├── resources/ (Views, Languages)
├── routes/ (Routes)
├── storage/ (ملفات التخزين)
├── vendor/ (Composer packages)
└── ... باقي الملفات
```

### 2.3 تعيين الصلاحيات
تعيين الصلاحيات التالية:

```
📁 المجلدات: 755
📄 الملفات: 644
```

- `storage/`: 755 (للقابلية للكتابة)
- `bootstrap/cache/`: 755
- `public_html/storage/`: 755

---

## ⚙️ الخطوة 3: تكوين ملف .env

### 3.1 تحديث ملف البيئة
1. تحرير ملف `.env` في `public_html`
2. تحديث القيم التالية:

```env
# معلومات الاستضافة
APP_ENV=production
APP_DEBUG=false
APP_URL=https://yourdomain.com

# معلومات قاعدة البيانات من Hostinger
DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=your_database_name
DB_USERNAME=your_database_user
DB_PASSWORD=your_database_password

# البريد الإلكتروني
MAIL_MAILER=smtp
MAIL_HOST=smtp.hostinger.com
MAIL_PORT=587
MAIL_USERNAME=noreply@yourdomain.com
MAIL_PASSWORD=your_email_password
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS="noreply@yourdomain.com"
```

### 3.2 إعداد API Keys (اختياري)
```env
# للمبتدئين - مجاني
OPENROUTER_API_KEY=sk-or-your-openrouter-key-here

# Google Maps (مجاني محدود)
GOOGLE_MAPS_API_KEY=your-google-maps-key-here
```

---

## 🔐 الخطوة 4: تفعيل SSL

### 4.1 من cPanel Hostinger
1. الدخول إلى **SSL/TLS**
2. اختيار **"Let's Encrypt SSL"**
3. تفعيل **"Force HTTPS Redirect"**
4. تطبيق شهادة SSL على النطاق

### 4.2 التحقق من SSL
1. زيارة `https://yourdomain.com`
2. التأكد من وجود قفل أخضر في المتصفح
3. التأكد من عمل جميع الروابط بـ HTTPS

---

## 🧪 الخطوة 5: اختبار النظام

### 5.1 اختبار الصفحة الرئيسية
```
✅ زيارة: https://yourdomain.com
✅ التحقق من تحميل الصفحة
✅ التحقق من عمل الصور CSS/JS
```

### 5.2 اختبار لوحة الإدارة
```
✅ زيارة: https://yourdomain.com/admin
✅ تسجيل الدخول: admin@clinic.com / admin123456
✅ التحقق من عرض Dashboard
✅ التحقق من عرض Integrations
```

### 5.3 اختبار النظام الأساسي
```
✅ إنشاء موعد جديد
✅ إرسال رسالة اتصال
✅ عرض الخدمات
✅ عمل صفحة من نحن
```

---

## 🔧 الخطوة 6: التكوين المتقدم

### 6.1 إنشاء Admin User جديد
1. تسجيل الدخول للوحة الإدارة
2. الذهاب إلى **Users**
3. إنشاء مستخدم مدير جديد
4. تغيير كلمة مرور المدير الافتراضي

### 6.2 تفعيل التكاملات
1. الذهاب إلى **API Integrations**
2. تفعيل **OpenRouter** (للمبتدئين)
3. تفعيل **Google Maps** (اختياري)
4. اختبار التكاملات

### 6.3 تكوين النظام
1. الذهاب إلى **Settings**
2. تحديث معلومات العيادة:
   - اسم العيادة
   - العنوان
   - رقم الهاتف
   - البريد الإلكتروني
3. تكوين ساعات العمل
4. ضبط إعدادات المواعيد

---

## 🚨 استكشاف الأخطاء وحلها

### ❌ خطأ "Database Connection Failed"
**السبب**: معلومات قاعدة البيانات خاطئة
**الحل**:
```bash
# فحص ملف .env
DB_CONNECTION=mysql
DB_HOST=localhost
DB_DATABASE=اسم_قاعدة_البيانات_الصحيح
DB_USERNAME=اسم_المستخدم_الصحيح
DB_PASSWORD=كلمة_المرور_الصحيحة
```

### ❌ خطأ "404 Not Found"
**السبب**: ملف .htaccess أو الإعدادات خاطئة
**الحل**:
```bash
# التأكد من وجود .htaccess في public_html
# التحقق من صلاحيات الملفات
# فحص mod_rewrite في Apache
```

### ❌ خطأ "Permission Denied"
**السبب**: صلاحيات المجلدات خاطئة
**الحل**:
```bash
# تعيين الصلاحيات الصحيحة
chmod 755 storage/
chmod 755 bootstrap/cache/
chmod 644 .env
```

### ❌ خطأ "Internal Server Error"
**السبب**: خطأ في كود PHP أو إعدادات
**الحل**:
```bash
# فحص error logs في cPanel
# التأكد من PHP version (8.2+)
# فحص ملف user.ini
```

### ❌ الملفات الثابتة لا تظهر
**السبب**: ملفات assets مفقودة
**الحل**:
```bash
# التأكد من وجود مجلد assets في public_html
# التأكد من وجود app.css و app.js
# فحص routes للأصول الثابتة
```

---

## 📊 قائمة التحقق النهائية

### قبل النشر:
- [ ] قاعدة البيانات مُنشأة ومُصدّرة
- [ ] ملف .env محدث بمعلومات Hostinger
- [ ] SSL مُفعل
- [ ] الصلاحيات مضبوطة بشكل صحيح
- [ ] جميع الملفات مرفوعة

### بعد النشر:
- [ ] الصفحة الرئيسية تعمل
- [ ] لوحة الإدارة تعمل
- [ ] إنشاء المواعيد يعمل
- [ ] نظام الرسائل يعمل
- [ ] SSL مُفعل ويعمل
- [ ] سرعة الموقع جيدة
- [ ] الموقع مُحسن للهواتف المحمولة

---

## 🎯 الخطوات التالية بعد النشر

### 1. المراقبة والصيانة:
- مراقبة سجلات الأخطاء
- نسخ احتياطية دورية
- تحديث النظام
- مراقبة الأداء

### 2. التحسينات:
- تفعيل المزيد من التكاملات
- تحسين سرعة الموقع
- إضافة محتوى أكثر
- تحسين SEO

### 3. التسويق:
- تفعيل Google Analytics
- تفعيل Meta Pixel
- إعداد Google Search Console
- تحسين محركات البحث

---

## 📞 الدعم والمساعدة

### 🆘 مشاكل شائعة وحلولها:

#### مشكلة: لا يمكنني تسجيل الدخول للوحة الإدارة
**الحل**:
1. التأكد من وجود user في جدول users
2. فحص كلمة المرور المُشفرة
3. تشغيل: `php artisan tinker` ثم إنشاء admin user جديد

#### مشكلة: التوقيت خاطئ في النظام
**الحل**:
1. تحديث ملف .env: `APP_TIMEZONE=Asia/Riyadh`
2. التأكد من إعدادات PHP timezone في user.ini

#### مشكلة: الإشعارات لا تعمل
**الحل**:
1. فحص إعدادات SMTP في .env
2. التأكد من إعدادات البريد الإلكتروني
3. فحص جدول integration_logs

### 📧 معلومات الدعم:
- **Documentación**: راجع الملفات في `/docs/`
- **Logs**: في `storage/logs/`
- **Database**: عبر phpMyAdmin في cPanel

---

## 🏁 الخلاصة

بمجرد إكمال هذه الخطوات، سيكون موقع عيادة د. عبدالناصر الأخصور جاهزاً بالكامل للعمل! النظام يحتوي على:

- ✅ **18 تكامل متقدم** جاهز للتفعيل
- ✅ **نظام إدارة شامل** مع Filament
- ✅ **واجهة مستخدم احترافية** مع chatbot ذكي
- ✅ **نظام مواعيد متكامل** 
- ✅ **أمان وحماية** متقدمة
- ✅ **محسن للاستضافة المشتركة**

**🎉 مبروك! مشروعك جاهز للإطلاق!**