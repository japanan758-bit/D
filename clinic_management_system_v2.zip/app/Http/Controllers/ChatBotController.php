<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;

class ChatBotController extends Controller
{
    // تكوين الـ APIs المختلفة
    private array $apiConfigs = [
        'gpt4' => [
            'endpoint' => 'https://api.openai.com/v1/chat/completions',
            'model' => 'gpt-4',
            'api_key' => env('OPENAI_API_KEY'),
            'pricing' => 'مدفوع',
            'name' => 'GPT-4'
        ],
        'claude' => [
            'endpoint' => 'https://api.anthropic.com/v1/messages',
            'model' => 'claude-3-sonnet-20240229',
            'api_key' => env('ANTHROPIC_API_KEY'),
            'pricing' => 'مدفوع',
            'name' => 'Claude'
        ],
        'gemini' => [
            'endpoint' => 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent',
            'model' => 'gemini-pro',
            'api_key' => env('GOOGLE_AI_API_KEY'),
            'pricing' => 'مدفوع',
            'name' => 'Gemini'
        ],
        'openrouter' => [
            'endpoint' => 'https://openrouter.ai/api/v1/chat/completions',
            'model' => 'anthropic/claude-3-haiku', // Default model
            'api_key' => env('OPENROUTER_API_KEY'),
            'pricing' => 'مجاني/مدفوع',
            'name' => 'OpenRouter'
        ]
    ];

    // ردود ذكية محلية (مُحسنة)
    private function getAdvancedLocalResponse(string $input): string
    {
        $input = strtolower($input);
        
        // قاعدة بيانات معرفة محسنة
        $knowledgeBase = [
            'حجز' => [
                'keywords' => ['حجز', 'موعد', 'مواعيد', 'كتاب'],
                'response' => "📅 **حجز المواعيد المتاحة:**\n\n🕐 **الأوقات المتوفرة:**\n• الأحد: 9:00 ص - 12:00 ص | 2:00 م - 5:00 م\n• الاثنين: 9:00 ص - 12:00 ص | 2:00 م - 6:00 م\n• الثلاثاء: 9:00 ص - 12:00 ص | 2:00 م - 6:00 م\n• الأربعاء: 9:00 ص - 12:00 ص | 2:00 م - 6:00 م\n• الخميس: 9:00 ص - 12:00 ص | 2:00 م - 6:00 م\n• الجمعة: 9:00 ص - 12:00 ص\n\n💡 **نصائح للحجز:**\n• احجز موعداً مبكراً للحصول على وقت مناسب\n• للفحوصات الدورية: احجز أول الأسبوع\n• للطوارئ: اتصل مباشرة: +966 11 234 5678\n\n🎯 **طرق الحجز:**\n1. حجز أونلاين من الموقع\n2. اتصال مباشر\n3. واتساب\n4. تطبيق هوا\n\n*ملاحظة: الحجز أونلاين متاح 24/7*\n\nهل تريد الحجز الآن؟ 😊"
            ],
            'سعر' => [
                'keywords' => ['سعر', 'تكلفة', 'قيمة', 'فلوس', 'كلفة'],
                'response' => "💰 **تفاصيل الأسعار والخدمات:**\n\n🩺 **الاستشارات:**\n• فحص شامل للعيون: **200 ريال**\n• استشارة شبكية متخصصة: **300 ريال**\n• فحص ضغط العين: **150 ريال**\n• فحص قاع العين: **200 ريال**\n• فحص النظر والانكسار: **120 ريال**\n• فحص قوس القرنية: **180 ريال**\n\n🏥 **العمليات:**\n• جراحة المياه البيضاء (الفاكو): **4,500 ريال**\n• زرع العدسة متعددة البؤرة: **+1,500 ريال**\n• زرع عدسة TORIC: **+1,000 ريال**\n• ليزر الشبكية: **800 ريال**\n• جراحة الجلوكوما: **6,000 ريال**\n• جراحة انفصال الشبكية: **8,000 ريال**\n\n🎁 **عروض خاصة:**\n• فحص مجاني للمعالجين: **المرة الأولى فقط**\n• خصم 10% للحوامل والرضع\n• تأمين طبي متوفر\n\n💳 **طرق الدفع:**\n• نقداً • بطاقة • تقسيط\n• جميع البنوك معتمدة\n\nهل تريد التفاصيل عن خدمة معينة؟ 🤔"
            ],
            'شبكية' => [
                'keywords' => ['شبكية', 'انفصال', 'تليف', 'الواجة'],
                'response' => "👁️ **خدمات جراحة الشبكية:**\n\n🔬 **التقنيات المتطورة:**\n• Micro Vitreoretinal Surgery (MIVS)\n• 23G و 25G vitrectomy\n• Laser-assisted surgery\n• Intraoperative OCT\n\n🩺 **العمليات المتوفرة:**\n• علاج انفصال الشبكية\n• إزالة الجلوكوما الدموية\n• علاج تليف الشبكية\n• استئصال الأغشية\n• حقن العين الخلفية\n• علاج ارتفاع الضغط البصري\n\n⚕️ **خدمات إضافية:**\n• فحوصات ما قبل العملية\n• المتابعة بعد العملية\n• التثقيف والتوعية\n• الدعم النفسي\n\n🏆 **إنجازاتنا:**\n• 1,500+ عملية ناجحة\n• معدل نجاح 98.5%\n• خبرة 20+ عام\n• أفضل النتائج في المملكة\n\n📋 **المتطلبات:**\n• فحص طبي شامل\n• تخطيط الشبكية\n• فحوصات مخبرية\n\n💬 **لمزيد من التفاصيل، احجز استشارة مجانية**\n\nهل تريد معلومات إضافية؟ 🌟"
            ],
            'مياه' => [
                'keywords' => ['مياه', 'بيضاء', 'سقوط', ' cataract'],
                'response' => "💧 **جراحة المياه البيضاء (الساد):**\n\n🔬 **التقنيات الحديثة:**\n• Phacoemulsification (Phaco)\n• Femtosecond Laser\n• Toric IOL Technology\n• Multifocal IOL\n• Crystalens and Symfony IOL\n\n💎 **أنواع العدسات:**\n• العدسات أحادية البؤرة: **الأساسية**\n• العدسات متعددة البؤرة: **4,500 ريال**\n• عدسات توريك: **+1,000 ريال**\n• عدسات متحركة: **+2,000 ريال**\n\n⏰ **أوقات العملية:**\n• العملية: 15-20 دقيقة\n• التخدير: موضعي + مهدئ\n• الإقامة: نفس اليوم\n• الشفاء: 2-4 أسابيع\n\n🎯 **معدل النجاح:**\n• تحسن النظر: 99.2%\n• مضاعفات: أقل من 1%\n• الحاجة لجراحة إضافية: 0.1%\n\n🏥 **التجهيزات:**\n• أحدث أجهزة الجراحة\n• غرف عمليات معقمة\n• رعاية متكاملة 24/7\n\n💡 **المتابعة:**\n• مراجعة بعد أسبوع\n• فحص شامل بعد شهر\n• متابعة دورية سنوياً\n\n*هل أنت مؤهل للعملية؟ احجز استشارة الآن!* 😊"
            ],
            'ليزر' => [
                'keywords' => ['ليزر', ' laser', 'ضوء'],
                'response' => "🔴 **علاج العيون بالليزر:**\n\n⚡ **أنواع الليزر:**\n• ياج ليزر للشبكية\n• دايود ليزر للقرنية\n• ارغون ليزر الشبكي\n• فيمتو ثانية ليزر\n• كربون ليزر\n\n🎯 **التطبيقات الطبية:**\n• علاج تسريب الأوعية الدموية\n• علاج ارتشاح الشبكية\n• منع انفصال الشبكية\n• علاج الجلوكوما\n• توسيع القناة الدمعية\n\n🔬 **التقنيات:**\n• Laser peripheral iridotomy\n• Laser trabecular surgery\n• Pan-retinal photocoagulation\n• Focal laser photocoagulation\n\n⏱️ **التفاصيل:**\n• مدة العملية: 10-30 دقيقة\n• التخدير: موضعي\n• الشفاء: 24-48 ساعة\n• المتابعة: أسبوعياً\n\n🏆 **معدلات النجاح:**\n• تحسن النظر: 90%\n• منع تدهور الشبكية: 95%\n• معدل نجاح الليزر: 98%\n\n💡 **الاستعداد للليزر:**\n• فحص شامل قبل العملية\n• تنظيف العين قبل العلاج\n• توجيتش محدد\n\n*الليزر آمن وفعال - استشر طبيبك الآن!* ✨"
            ],
            'جلوكوما' => [
                'keywords' => ['جلوكوما', 'مياه', 'زرقاء', ' glaucoma'],
                'response' => "👁️ **علاج الجلوكوما (المياه الزرقاء):**\n\n🔍 **التشخيص المتقدم:**\n• فحص ضغط العين (IOP)\n• OCT للقاع البصري\n• فحص بصري شامل\n• تقييم العصب البصري\n• قياس سمك القرنية\n\n💊 **العلاج بالادوية:**\n• قطرات موضعية (الخط الأول)\n• أدوية الفم (الحالات المتقدمة)\n• مزيج من الأدوية\n• مراقبة دورية لضغط العين\n\n⚡ **العلاج بالليزر:**\n•Selective Laser Trabeculoplasty (SLT)\n• Laser Trabecular Surgery (LTS)\n• Laser Peripheral Iridotomy\n•argon laser ترابيكولوبلاستي\n\n🔪 **الجراحات المتقدمة:**\n• جراحة التصفية التقليدية\n• زراعة صمامات المياه\n• MIGS (الجراحة طفيفة التوغل)\n• جراحة ليزر جديدة\n\n📊 **معدلات النجاح:**\n• فقدان البصر: تقليل 50%\n• التحكم في الضغط: 85%\n• تحسين جودة الحياة: 92%\n\n⏰ **المتابعة:**\n• فحص دوري كل 3-6 أشهر\n• مراقبة تقدم المرض\n• تعديل العلاج حسب الحاجة\n\n*التشخيص المبكر ينقذ بصرك! احجز فحصاً دورياً الآن* 💚"
            ],
            'دكتور' => [
                'keywords' => ['دكتور', 'طبيب', 'د.', 'أخصور', 'نبذة'],
                'response' => "👨‍⚕️ **د. عبدالناصر الأخصور:**\n\n🎓 **المؤهلات الأكاديمية:**\n• بكالوريوس الطب والجراحة - جامعة الملك سعود\n• دبلوم طب وجراحة العيون\n• زمالة جراحة الشبكية - مستشفى ويليس آي\n• معاييرBoard Certified في طب العيون\n\n🏆 **الخبرة المهنية:**\n• خبرة 20+ سنة في طب العيون\n• أكثر من 15,000 عملية ناجحة\n• خبير في جراحة الشبكية والمياه البيضاء\n• رائد في استخدام التقنيات الحديثة\n\n🏅 **الاعتمادات والشهادات:**\n• American Academy of Ophthalmology\n• International Society of Retina Specialists\n• Saudi Arabian Board of Ophthalmology\n• European Society of Retina Specialists\n\n🏢 **الوظائف الحالية:**\n• أخصائي جراحة العيون - العيادة الخاصة\n• استشاري الشبكية\n• عضو هيئة التدريس - كلية الطب\n• خبير استشاري في مستشفيات الرياض\n\n🌟 **الإنجازات:**\n• أفضل نتائج في المنطقة\n• معدل نجاح 98.5%\n• حاصل على جوائز التميز\n• مدرب للأطباء الجدد\n\n💝 **الفلسفة:**\n\"الهدف هو رؤيتكم بوضوح... رؤيتكم هي رؤيتنا\"\n\n*لمزيد من المعلومات، احجز استشارة شخصية* 😊"
            ],
            'عجلة' => [
                'keywords' => ['عجلة', '24/7', 'طوارئ', 'إسعاف'],
                'response' => "🚨 **طوارئ العيون (متاح 24/7):**\n\n🚑 **الخدمات الطارئة:**\n• انفصال الشبكية\n• اختراق العين\n• حروق كيميائية\n• النزيف الداخلي\n• ضياع الرؤية المفاجئ\n• الم شديد في العين\n\n📞 **للاتصال الطارئ:**\n**+966 11 234 5678**\n**+966 50 123 4567** (واتساب طوارئ)\n\n🚗 **الاستجابة:**\n• خلال 15 دقيقة في العيادة\n• خلال 30 دقيقة في المنزل (جدة/الرياض)\n• استشارة عاجلة عبر واتساب\n\n🏥 **البنية التحتية:**\n• فريق طوارئ 24/7\n• معدات متقدمة\n• سيارة إسعاف مجهزة\n• غرفة عمليات طوارئ\n\n💡 **نصائح الطوارئ:**\n• لا تفرك العين المصابة\n• لا تستخدم قطرات بدون إرشاد\n• احضر قائمة بأدويتك\n• جلب شخص مرافق\n\n⏰ **الخدمات:**\n• التشخيص العاجل\n• العلاج الفوري\n• المتابعة المكثفة\n• إعادة التأهيل البصري\n\n*في حالات الطوارئ... الوقت يعني البصر!* ⚡"
            ]
        ];

        // البحث عن المطابقة الأفضلية
        $bestMatch = null;
        $highestScore = 0;

        foreach ($knowledgeBase as $topic => $data) {
            $score = 0;
            foreach ($data['keywords'] as $keyword) {
                if (strpos($input, $keyword) !== false) {
                    $score += substr_count($input, $keyword);
                }
            }
            
            if ($score > $highestScore) {
                $highestScore = $score;
                $bestMatch = $data['response'];
            }
        }

        return $bestMatch ?? $this->getDefaultResponse($input);
    }

    // الرد الافتراضي المحسن
    private function getDefaultResponse(string $input): string
    {
        return "شكراً لسؤالك! 🤔\n\nلم أفهم طلبك بالضبط، لكن يمكنني مساعدتك في:\n\n🏥 **الخدمات الطبية:**\n• حجز المواعيد\n• معلومات عن الخدمات\n• الأسعار والتكاليف\n• الطوارئ 24/7\n\n👨‍⚕️ **معلومات عن الدكتور:**\n• المؤهلات والخبرة\n• الإنجازات والشهادات\n\n📞 **طرق التواصل:**\n• الهاتف والواتساب\n• العيادة والمواعيد\n• الخرائط والاتجاهات\n\n💻 **التقنيات:**\n• فحص شامل للعيون\n• جراحات الشبكية والمياه البيضاء\n• علاج الجلوكوما والليزر\n\nهل تريد المساعدة في موضوع معين؟ أو يمكنك سؤال:\n\n\"أريد معرفة سعر جراحة المياه البيضاء\"\n\"كيف أحجز موعد؟\"\n\"أحدث عن الخدمات\"\n\nسأكون سعيداً لمساعدتك! 😊";
    }

    // إدارة الرسائل
    public function handleMessage(Request $request)
    {
        $request->validate([
            'message' => 'required|string|max:1000',
            'api_type' => 'string|in:intelligent,gpt4,claude,gemini,openrouter,local'
        ]);

        $userMessage = $request->input('message');
        $apiType = $request->input('api_type', 'intelligent');

        try {
            $response = match($apiType) {
                'intelligent' => $this->getAdvancedLocalResponse($userMessage),
                'gpt4' => $this->callGPT4API($userMessage),
                'claude' => $this->callClaudeAPI($userMessage),
                'gemini' => $this->callGeminiAPI($userMessage),
                'openrouter' => $this->callOpenRouterAPI($userMessage),
                'local' => $this->getAdvancedLocalResponse($userMessage),
                default => $this->getAdvancedLocalResponse($userMessage)
            };

            return response()->json([
                'success' => true,
                'response' => $response,
                'api_type' => $apiType,
                'timestamp' => now()->toISOString()
            ]);

        } catch (\Exception $e) {
            Log::error('Chat bot error: ' . $e->getMessage());
            
            return response()->json([
                'success' => false,
                'response' => "عذراً، حدث خطأ تقني. يرجى المحاولة مرة أخرى أو التواصل معنا مباشرة.\n\n📞 الهاتف: +966 11 234 5678\n📱 واتساب: +966 11 234 5678",
                'error' => $e->getMessage()
            ], 500);
        }
    }

    // استدعاء OpenAI GPT-4
    private function callGPT4API(string $message): string
    {
        $cacheKey = 'gpt4_response_' . md5($message);
        
        if (Cache::has($cacheKey)) {
            return Cache::get($cacheKey);
        }

        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiConfigs['gpt4']['api_key'],
                'Content-Type' => 'application/json'
            ])->post($this->apiConfigs['gpt4']['endpoint'], [
                'model' => $this->apiConfigs['gpt4']['model'],
                'messages' => [
                    [
                        'role' => 'system',
                        'content' => 'أنت مساعد ذكي لعيادة د. عبدالناصر الأخصور للعيون في السعودية. تقدم معلومات طبية دقيقة ومفيدة عن خدمات العيادة، الأسعار، والمواعيد. استجب باللغة العربية بتفصيل واضح ومفيد.'
                    ],
                    [
                        'role' => 'user',
                        'content' => $message
                    ]
                ],
                'max_tokens' => 1000,
                'temperature' => 0.7
            ]);

            if ($response->successful()) {
                $aiResponse = $response->json('choices.0.message.content');
                $result = "🤖 **تم الرد بواسطة GPT-4:**\n\n" . $aiResponse . "\n\n⚡ *تم توليد هذا الرد بواسطة ChatGPT-4*";
                
                // Cache the response for 30 minutes
                Cache::put($cacheKey, $result, 1800);
                
                return $result;
            }
            
        } catch (\Exception $e) {
            Log::error('GPT-4 API error: ' . $e->getMessage());
        }

        return $this->getAdvancedLocalResponse($message);
    }

    // استدعاء Anthropic Claude
    private function callClaudeAPI(string $message): string
    {
        try {
            $response = Http::withHeaders([
                'x-api-key' => $this->apiConfigs['claude']['api_key'],
                'Content-Type' => 'application/json',
                'anthropic-version' => '2023-06-01'
            ])->post($this->apiConfigs['claude']['endpoint'], [
                'model' => $this->apiConfigs['claude']['model'],
                'max_tokens' => 1000,
                'messages' => [
                    [
                        'role' => 'user',
                        'content' => 'أنت مساعد ذكي لعيادة د. عبدالناصر الأخصور للعيون. السؤال: ' . $message
                    ]
                ]
            ]);

            if ($response->successful()) {
                $aiResponse = $response->json('content.0.text');
                return "🤖 **تم الرد بواسطة Claude:**\n\n" . $aiResponse . "\n\n🧠 *تم توليد هذا الرد بواسطة Claude AI*";
            }
            
        } catch (\Exception $e) {
            Log::error('Claude API error: ' . $e->getMessage());
        }

        return $this->getAdvancedLocalResponse($message);
    }

    // استدعاء Google Gemini
    private function callGeminiAPI(string $message): string
    {
        try {
            $response = Http::post($this->apiConfigs['gemini']['endpoint'] . '?key=' . $this->apiConfigs['gemini']['api_key'], [
                'contents' => [
                    [
                        'parts' => [
                            [
                                'text' => 'أنت مساعد ذكي لعيادة د. عبدالناصر الأخصور. السؤال: ' . $message
                            ]
                        ]
                    ]
                ]
            ]);

            if ($response->successful()) {
                $aiResponse = $response->json('candidates.0.content.parts.0.text');
                return "🤖 **تم الرد بواسطة Gemini:**\n\n" . $aiResponse . "\n\n💎 *تم توليد هذا الرد بواسطة Google Gemini*";
            }
            
        } catch (\Exception $e) {
            Log::error('Gemini API error: ' . $e->getMessage());
        }

        return $this->getAdvancedLocalResponse($message);
    }

    // استدعاء OpenRouter API
    private function callOpenRouterAPI(string $message): string
    {
        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->apiConfigs['openrouter']['api_key'],
                'Content-Type' => 'application/json',
                'HTTP-Referer' => env('APP_URL', 'https://clinic.com'),
                'X-Title' => 'Dr. Al-Akhras Clinic ChatBot'
            ])->post($this->apiConfigs['openrouter']['endpoint'], [
                'model' => $this->apiConfigs['openrouter']['model'],
                'messages' => [
                    [
                        'role' => 'system',
                        'content' => 'أنت مساعد ذكي متخصص في الخدمات الطبية لعيادة د. عبدالناصر الأخصور للعيون في المملكة العربية السعودية. تقدم معلومات دقيقة عن:\n\n🏥 خدمات العيادة:\n• فحص شامل للعيون (200 ريال)\n• استشارة شبكية متخصصة (300 ريال)\n• جراحة المياه البيضاء (4,500 ريال)\n• جراحة الشبكية (8,000 ريال)\n• علاج الجلوكوما (6,000 ريال)\n• علاج بالليزر (800 ريال)\n\n📞 للتواصل:\n• الهاتف: +966 11 234 5678\n• واتساب: +966 50 123 4567\n• العنوان: الرياض، المملكة العربية السعودية\n\nاستجب باللغة العربية بتفصيل واضح ومفيد. كن ودوداً ومتفهماً لاحتياجات المرضى.'
                    ],
                    [
                        'role' => 'user',
                        'content' => $message
                    ]
                ],
                'max_tokens' => 1000,
                'temperature' => 0.7,
                'top_p' => 0.9
            ]);

            if ($response->successful()) {
                $aiResponse = $response->json('choices.0.message.content');
                $result = "🤖 **تم الرد بواسطة OpenRouter:**\n\n" . $aiResponse . "\n\n🌐 *تم توليد هذا الرد بواسطة OpenRouter AI*";
                
                return $result;
            }
            
        } catch (\Exception $e) {
            Log::error('OpenRouter API error: ' . $e->getMessage());
        }

        return $this->getAdvancedLocalResponse($message);
    }

    // إحصائيات الشات بوت
    public function getStatistics()
    {
        return response()->json([
            'total_messages' => Cache::get('total_messages', 0),
            'api_usage' => [
                'intelligent' => Cache::get('api_intelligent_count', 0),
                'gpt4' => Cache::get('api_gpt4_count', 0),
                'claude' => Cache::get('api_claude_count', 0),
                'gemini' => Cache::get('api_gemini_count', 0),
                'openrouter' => Cache::get('api_openrouter_count', 0)
            ],
            'popular_questions' => Cache::get('popular_questions', []),
            'uptime' => now()->diffForHumans(Cache::get('bot_start_time', now())),
        ]);
    }

    // تسجيل حدث جديد
    private function logUsage(string $apiType): void
    {
        Cache::increment('api_' . $apiType . '_count');
        Cache::increment('total_messages');
        Cache::put('bot_start_time', now(), 86400);
    }
}
